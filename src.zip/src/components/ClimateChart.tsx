"use client";

import { Line } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from "chart.js";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

interface ClimateData {
  monthly_data: {
    month: number;
    data: { measure: string; value: number }[];
  }[];
}

const ClimateChart = ({ climateData }: { climateData: ClimateData }) => {
  const months = climateData.monthly_data.map((m) => m.month);
  const tMax = climateData.monthly_data.map((m) => m.data.find((d) => d.measure === "t_max")?.value ?? 0);
  const tMin = climateData.monthly_data.map((m) => m.data.find((d) => d.measure === "t_min")?.value ?? 0);
  const prec = climateData.monthly_data.map((m) => m.data.find((d) => d.measure === "prec")?.value ?? 0);
  const solRad = climateData.monthly_data.map((m) => m.data.find((d) => d.measure === "sol_rad")?.value ?? 0);

  const createChartData = (label: string, data: number[], color: string) => ({
    labels: months.map((m) => `Mes ${m}`),
    datasets: [
      {
        label,
        data,
        borderColor: color,
        backgroundColor: color,
        fill: false,
      },
    ],
  });

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="bg-white shadow-md rounded-lg p-4">
        <h2 className="text-xl font-bold">Temperatura Máxima (°C)</h2>
        <Line data={createChartData("Temp. Máx", tMax, "red")} />
      </div>
      <div className="bg-white shadow-md rounded-lg p-4">
        <h2 className="text-xl font-bold">Temperatura Mínima (°C)</h2>
        <Line data={createChartData("Temp. Mín", tMin, "blue")} />
      </div>
      <div className="bg-white shadow-md rounded-lg p-4">
        <h2 className="text-xl font-bold">Precipitación (mm)</h2>
        <Line data={createChartData("Precipitación", prec, "green")} />
      </div>
      <div className="bg-white shadow-md rounded-lg p-4">
        <h2 className="text-xl font-bold">Radiación Solar</h2>
        <Line data={createChartData("Radiación Solar", solRad, "orange")} />
      </div>
    </div>
  );
};

export default ClimateChart;