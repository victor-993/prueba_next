"use client";
import Link from "next/link";

const Navbar = () => {
  return (
    <>
    <header className="bg-white py-2 flex flex-cole items-center">
        <h1 className="mx-auto flex items-center">
            <a href=""><img alt="logo" src="https://colombia.aclimate.org/Environment/Colombia/logo.png" className="text-center" /></a>
        </h1>
    </header>
    <nav className="bg-green-500 p-4">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/">
          <span className="text-white text-xl font-bold">AClimate</span>
        </Link>
        <ul className="flex space-x-6">
          <li><Link href="/weather" className="text-white">Weather</Link></li>
          <li><Link href="/reports" className="text-white">Reports</Link></li>
          <li><Link href="/about" className="text-white">About</Link></li>
        </ul>
      </div>
    </nav>
    </>
    
  );
};

export default Navbar;